# Provenance

## Upstream Influence
- agency-agents/project-management/project-management-project-shepherd.md
- agency-agents/specialized/agents-orchestrator.md

## House Standard
- `open-claw/AI_Employee_knowledgebase/AUTHORITATIVE_STANDARD.md`
- `open-claw/AI_Employee_knowledgebase/TEAM_ROSTER.md`

## Notes
This packet is a curated derivative. It uses the proactive multi-file employee layout, the strongest specialist content from upstream role libraries, and current Next.js/Playwright guidance pulled through Context7 during this build.
