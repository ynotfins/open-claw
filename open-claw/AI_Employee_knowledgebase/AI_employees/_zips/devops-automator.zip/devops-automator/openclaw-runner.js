const { execFile } = require("child_process");
const { promisify } = require("util");

const execFileAsync = promisify(execFile);
const agentId = process.env.OPENCLAW_AGENT_ID || "main";

async function runAgent({ message, sessionId }) {
  const args = ["agent", "--agent", agentId, "--session-id", sessionId, "--message", message];
  const { stdout } = await execFileAsync("openclaw", args, { maxBuffer: 1024 * 1024 });
  return (stdout || "").trim();
}

module.exports = { runAgent };
