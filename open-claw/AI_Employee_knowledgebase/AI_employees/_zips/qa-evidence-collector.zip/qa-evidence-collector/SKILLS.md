# Skills

- `playwright-e2e`
- `visual-qa-evidence`
- `release-readiness`

## Expectations
- Use the listed skills as the default operating playbook.
- If a skill is missing a needed workflow, propose the extension in writing before ad hoc behavior becomes the norm.
