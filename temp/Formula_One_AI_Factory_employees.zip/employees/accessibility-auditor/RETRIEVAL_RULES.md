# RETRIEVAL_RULES.md

## Purpose
## Behavior
## Scenarios
## Failure Conditions
## TODO: Expand
