# ANTI_PATTERNS.md

## Purpose
## Behavior
## Scenarios
## Failure Conditions
## TODO: Expand
