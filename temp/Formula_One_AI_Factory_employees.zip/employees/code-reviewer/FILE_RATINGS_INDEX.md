# FILE_RATINGS_INDEX.md — Code Reviewer

## Rating Table

| File | Build Rating | Confidence | Status | Impact Weight | Notes |
| --- | --- | --- | --- | --- | --- |
| AGENTS.md | 6.0 | scaffold | generated | critical | Needs role-specific upgrade |
| SOUL.md | 6.0 | scaffold | generated | critical | Needs role-specific upgrade |
| IDENTITY.md | 5.5 | scaffold | generated | critical | Needs deep role specialization |
| MISSION.md | 5.5 | scaffold | generated | critical | Needs specific success criteria |
| OPERATING_RULES.md | 6.0 | scaffold | generated | critical | Needs role-specific decision rules |
| WORKFLOWS.md | 5.0 | scaffold | generated | critical | Needs detailed workflow steps |
| SKILLS.md | 5.0 | scaffold | generated | high | Needs concrete skill descriptions |
| TOOLS.md | 5.5 | scaffold | generated | high | Needs real tool configurations |
| SECURITY.md | 6.0 | scaffold | generated | critical | Needs domain-specific threats |
| TEST_CASES.md | 5.0 | scaffold | generated | high | Needs domain-specific test cases |
| manifest.json | 6.5 | scaffold | generated | high | Structurally complete |
| CONTEXT7_LIBRARIES.json | 6.0 | scaffold | generated | high | Libraries registered |

## Rating Methodology

- **Build Rating (1-10):** Quality assessment at build time, without field testing
- **Confidence:** scaffold = generated from template, low = early draft, medium = reviewed, high = field-tested
- **Status:** generated = from automation, draft = human-edited, reviewed = peer-reviewed, validated = field-tested
- **Impact Weight:** critical = blocks deployment, high = degrades quality, medium = nice to have
- **Notes:** Specific observations about the file's current state

## Rating Rules

- No critical file below Build Rating 7 for deployment readiness
- No file with confidence "scaffold" is deployment-ready
- All scaffolded files require upgrade pass before deployment
- Field Rating (1-15) added only after real operational use

---
*Ratings must be honest. Inflated ratings are themselves a governance defect.*
