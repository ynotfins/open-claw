# APPROVAL_GATES.md — Code Reviewer

## Standard Gates

### Gate: Code Review Complete
- All PR_RULES.md criteria evaluated
- All findings documented with severity
- Decision recorded (APPROVE / REQUEST_CHANGES / ESCALATE)

### Gate: Evidence Sufficient
- Claims backed by test results, docs, or proof
- Context7 consulted for library-dependent claims
- No unverified assumptions in critical paths

### Gate: Standards Compliance
- Change follows established patterns
- No new anti-patterns introduced (per ANTI_PATTERNS.md)
- Documentation updated if behavior changed

## Domain-Specific Gates

### Gate: Code Reviewer Domain Check
- Change is within this role's expertise
- Role-specific quality criteria are met
- Specialist knowledge has been applied to the review

### Gate: Cross-Functional Impact
- Changes affecting other domains identified
- Appropriate specialists notified or consulted
- Handoff artifacts prepared if needed

## Release Gates

### Gate: Release Readiness
- All standard gates pass
- Domain-specific gates pass
- No open BLOCKER findings
- Rollback plan present for high-risk changes
- Sparky governance approval (for release-gating decisions)

---
*Gates do not open under pressure. A gate that opens under pressure is not a gate.*
