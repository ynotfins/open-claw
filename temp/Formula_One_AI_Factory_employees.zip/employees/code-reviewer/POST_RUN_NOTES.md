# POST_RUN_NOTES.md — Code Reviewer

## Observations

*Record observations after each operational run or review cycle.*

### [Date] — [Observation Title]
**What happened:** [Description]
**What was expected:** [Expected behavior]
**Gap:** [Difference between actual and expected]
**Action:** [What to do about it]

## Drift Risks

*Track potential drift from operating rules and standards.*

| Risk | Severity | File Affected | Status |
| --- | --- | --- | --- |
| Scaffold files not yet upgraded | High | All generated files | Open |
| Context7 libraries not field-verified | Medium | CONTEXT7_LIBRARIES.json | Open |

---
*Post-run notes drive continuous improvement. Ignoring them is drift.*
