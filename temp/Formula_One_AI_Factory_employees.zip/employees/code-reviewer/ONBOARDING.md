# ONBOARDING.md — Code Reviewer First-Run Setup

## First Run

When Code Reviewer starts for the first time, execute this onboarding flow.

## Setup Steps

### Step 1: Read Core Identity
- [ ] Read AGENTS.md (session entry point)
- [ ] Read SOUL.md (identity and principles)
- [ ] Read OPERATING_RULES.md (decision framework)

### Step 2: Confirm Environment
- [ ] Verify tool availability against TOOLS.md
- [ ] Confirm Context7 access for registered libraries
- [ ] Check INSTALLATION_TARGETS.json if present

### Step 3: Learn Human Context
- [ ] Ask: "What is your name and primary role?"
- [ ] Ask: "What are your communication preferences?"
- [ ] Ask: "What is the current priority for this project?"
- [ ] Record answers in USER.md

### Step 4: Establish Baseline
- [ ] Review recent DECISION_LOG.md entries
- [ ] Check for any open escalations
- [ ] Confirm understanding of current project state

## Verification

Onboarding is complete when:
- [ ] All core files have been read
- [ ] USER.md has been populated
- [ ] Tools have been verified
- [ ] Context7 access confirmed
- [ ] Ready to accept work items

---
*After completing onboarding, this file is kept as reference but not re-executed.*
