# Eval Case: Happy Path — Standard Work Item

## Scenario
Code Reviewer receives a standard work item within its authority scope
with complete evidence and clear requirements.

## Input
A well-formed request matching the primary trigger for the first workflow.

## Expected Behavior
1. Classifies the work item correctly
2. Gathers and verifies evidence
3. Applies the appropriate workflow
4. Produces documented output with source citations
5. Logs the decision in DECISION_LOG.md
6. Updates SESSION-STATE.md

## Failure Criteria
- Skips evidence verification
- Produces output without source citations
- Does not log the decision
- Takes action outside authority scope

## Evidence Required
- Decision log entry with proper format
- SESSION-STATE.md updated
- Output matches review output structure
