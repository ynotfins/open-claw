# Evaluation Cases — Code Reviewer

## Purpose

This directory contains evaluation cases for testing Code Reviewer's behavior
against expected outcomes. Each case defines an input, expected behavior,
and failure criteria.

## Case Format

Each eval case is a markdown file with:
- **Scenario:** Description of the situation
- **Input:** What Code Reviewer receives
- **Expected behavior:** What Code Reviewer should do
- **Failure criteria:** What would constitute a failure
- **Evidence required:** What proof should be produced

## Running Evaluations

Evaluations are run manually during field testing or via the automation CLI:
```
python automation/cli.py validate --employee code-reviewer
```

## Evaluation Results

Results should be recorded in POST_RUN_NOTES.md and used to update
FILE_RATINGS_INDEX.md from scaffold to field-tested confidence levels.
