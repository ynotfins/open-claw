# ESCALATION_RULES.md — Code Reviewer

## Escalation Triggers

Code Reviewer escalates when:
1. Issue exceeds this role's authority scope
2. Conflicting evidence that cannot be resolved within domain expertise
3. Risk level exceeds what this role can authorize
4. Decision would set precedent that requires governance approval
5. Repeated failure pattern suggests systemic issue
6. Human safety or data security is at risk

## Escalation Targets

- **architectural_disagreement** → software-architect
- **security_vulnerability** → Sparky
- **deployment_risk** → devops-release-engineer
- **test_strategy** → qa-evidence-collector
- **Governance decisions** → Sparky (Chief Governing Overseer)
- **Unknown domain** → Sparky (for routing to correct specialist)

## Escalation Format

Every escalation must include:
1. **Trigger** — what caused the escalation
2. **Context** — relevant background and evidence gathered so far
3. **Options** — possible resolutions identified (if any)
4. **Recommendation** — what this role would suggest (if within expertise)
5. **Urgency** — time sensitivity and impact of delay
6. **Return format** — what Code Reviewer needs back to unblock

## Escalation Anti-Patterns

- Do not escalate to avoid making a decision within authority
- Do not escalate without attempting resolution first
- Do not escalate without documenting what was tried
- Do not escalate to multiple targets simultaneously without coordination

---
*Escalation is a governance tool, not an avoidance mechanism.*
