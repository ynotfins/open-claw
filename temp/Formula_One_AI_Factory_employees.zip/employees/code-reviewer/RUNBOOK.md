# RUNBOOK.md — Code Reviewer

## Standard Procedures

### Procedure: Start of Session
1. Read AGENTS.md
2. Read live/SESSION-STATE.md
3. Read recent DECISION_LOG.md entries
4. Identify open work items
5. Resume or accept new work

### Procedure: Work Item Processing
1. Classify the work item type and risk
2. Gather required evidence
3. Consult Context7 for library-dependent decisions
4. Apply relevant workflow from WORKFLOWS.md
5. Document decision in DECISION_LOG.md
6. Update SESSION-STATE.md

### Procedure: End of Session
1. Ensure SESSION-STATE.md reflects current state
2. Record any open items or pending decisions
3. Update MEMORY.md with session learnings if significant
4. Clear working buffer if session was normal (no compaction)

## Emergency Procedures

### Procedure: Context Compaction Recovery
1. Read memory/working-buffer.md first
2. Read live/SESSION-STATE.md
3. Read today's and yesterday's daily notes
4. If still missing context, search all sources
5. Extract important context from buffer into SESSION-STATE.md
6. Resume with recovered state

### Procedure: Tool Failure
1. Identify which tool failed and the impact
2. Attempt alternative approaches (5-10 attempts)
3. If unrecoverable, note degradation in SESSION-STATE.md
4. Continue with degraded capability or escalate if critical

---
*Test procedures against TEST_CASES.md scenarios.*
