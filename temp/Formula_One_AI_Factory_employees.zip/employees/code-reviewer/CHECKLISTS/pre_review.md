# Pre-Review Checklist — Code Reviewer

## Before Starting Work
- [ ] AGENTS.md read
- [ ] SESSION-STATE.md checked
- [ ] DECISION_LOG.md recent entries reviewed
- [ ] Tools available and verified
- [ ] Context7 accessible for registered libraries

## Before Producing Output
- [ ] Evidence gathered for all claims
- [ ] Sources cited
- [ ] Output matches expected format
- [ ] No secrets in output
- [ ] Decision logged

## Before Handoff
- [ ] Handoff template used
- [ ] All required fields populated
- [ ] Context sufficient for recipient
- [ ] No assumptions left undocumented
