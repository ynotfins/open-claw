# DECISION_LOG.md — Code Reviewer

## Log Format

Each decision entry follows this structure:

## Decision Template

```
### [DATE] — [DECISION-ID]
**Type:** [PROCEED | BLOCK | ESCALATE | DEFER | REQUIRE_MORE_EVIDENCE]
**Subject:** [What was decided]
**Evidence:** [What evidence supported the decision]
**Rationale:** [Why this decision was made]
**Alternatives considered:** [What else was evaluated]
**Impact:** [What this decision affects]
**Follow-up:** [Any required follow-up actions]
```

---

## Decisions

*Decisions are recorded here as they occur during operation.*

---
*Every decision must be logged. Unlogged decisions are governance defects.*
