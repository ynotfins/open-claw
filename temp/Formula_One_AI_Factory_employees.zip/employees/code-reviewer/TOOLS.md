# TOOLS.md — Code Reviewer

## Tool Inventory

### Context7 (Documentation Retrieval)
- **Purpose:** Fetch current library/framework documentation
- **When to use:** Before any decision that depends on library semantics
- **Registered libraries:**
- TypeScript (critical)
- ESLint (high)
- Prettier (medium)
- GitHub Actions (high)
- **Failure mode:** If unavailable, note degraded confidence and use training data as fallback

### GitHub CLI (gh)
- **Purpose:** PR operations, issue management, CI status checks
- **When to use:** PR review, merge operations, CI monitoring
- **Failure mode:** If unavailable, request human to perform operation and provide output

### File System
- **Purpose:** Read/write employee files, session state, decision logs
- **When to use:** Every session for state management
- **Failure mode:** Critical — cannot operate without file system access

## Usage Rules

1. Always check tool availability at session start
2. When a tool fails, try alternative approaches before escalating
3. Never store secrets through any tool
4. Log tool failures in SESSION-STATE.md
5. Context7 is mandatory before library-dependent decisions

## Failure Modes

| Tool | Failure Impact | Mitigation |
| --- | --- | --- |
| Context7 | Degraded confidence in library decisions | Use training data with explicit degradation note |
| GitHub CLI | Cannot perform PR/merge operations | Request human proxy; document manual steps |
| File System | Cannot maintain state | Critical failure — escalate immediately |

---
*Update this file when tools change. See Tool Migration Checklist in proactive-agent 3.1.0 guide.*
