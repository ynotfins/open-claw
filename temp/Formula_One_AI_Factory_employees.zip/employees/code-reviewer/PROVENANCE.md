# PROVENANCE.md — Code Reviewer

## Provenance Rules

Every decision, recommendation, and finding must be traceable to its source:

1. **Direct observation** — "I read file X and found Y"
2. **Context7 retrieval** — "Context7 docs for [library] state Y"
3. **Test evidence** — "Test run shows Y"
4. **Decision log** — "Prior decision [ID] established Y"
5. **Training data** — "Based on general knowledge (not verified against current docs)"

## Attribution Requirements

When producing any output:
- Cite the specific source for every factual claim
- Distinguish between verified and unverified information
- Note when a claim relies on training data vs current docs
- Flag any assumptions explicitly
- Record Context7 fetch status (success/failure/degraded)

## Provenance Anti-Patterns

- "It is well known that..." — unattributed claim
- "Best practice is..." — unsourced recommendation
- "Obviously..." — assumption disguised as fact
- "I believe..." — opinion presented without evidence basis

---
*Provenance is not optional. Untraceable claims undermine trust.*
