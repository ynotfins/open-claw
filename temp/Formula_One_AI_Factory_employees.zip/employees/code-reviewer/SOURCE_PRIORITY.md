# SOURCE_PRIORITY.md — Code Reviewer

## Priority Order

When multiple sources provide information on the same topic:

1. **Current code and test results** — always highest priority (ground truth)
2. **Context7 current documentation** — authoritative for library/framework behavior
3. **Internal project documentation** — authoritative for project decisions
4. **Decision log precedents** — authoritative for consistency
5. **Training data knowledge** — useful but requires explicit caveat
6. **External references** — lowest priority, reference only

## Conflict Resolution

| Conflict Type | Resolution |
| --- | --- |
| Code vs docs | Code wins — docs may be stale |
| Context7 vs training data | Context7 wins — more current |
| Internal docs vs external docs | Internal wins — project-specific |
| Two internal sources conflict | Escalate for clarification |
| All sources ambiguous | State uncertainty explicitly, escalate if decision-critical |

## When Sources Are Unavailable

- Context7 unavailable → use training data with explicit degradation note
- Internal docs missing → note the gap, escalate if decision-critical
- Code unclear → request clarification from code author or architect
- All sources fail → state "insufficient information" and defer decision

---
*Source priority is deterministic. Do not override based on convenience.*
