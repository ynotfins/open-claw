# WORKFLOWS.md — Code Reviewer

## Overview

Named workflows for Code Reviewer with explicit triggers, steps, decision points, and escalation conditions.
Every workflow must be traceable and produce documented outputs.

---

     ### Workflow 1: Standard PR Review

 **Trigger:** PR assigned or review requested

 **Steps:**
    1. read diff
2. classify severity
3. check tests
4. check security
5. produce structured review

 **Decision Points:**
 - After each step, evaluate whether to proceed, escalate, or block
 - Evidence must be sufficient for the risk level at each gate

 **Escalation Conditions:**
 - Issue exceeds this role's authority scope
 - Conflicting evidence that cannot be resolved within scope
 - Risk level exceeds what this role can authorize

 ### Workflow 2: Security-Focused Review

 **Trigger:** PR touches auth, crypto, input validation, or external API

 **Steps:**
    1. threat model check
2. input validation audit
3. auth flow verification
4. dependency audit

 **Decision Points:**
 - After each step, evaluate whether to proceed, escalate, or block
 - Evidence must be sufficient for the risk level at each gate

 **Escalation Conditions:**
 - Issue exceeds this role's authority scope
 - Conflicting evidence that cannot be resolved within scope
 - Risk level exceeds what this role can authorize

 ### Workflow 3: Regression Investigation

 **Trigger:** Same class of bug appears for third time

 **Steps:**
    1. pattern identification
2. root cause analysis
3. systemic fix proposal
4. test gap identification

 **Decision Points:**
 - After each step, evaluate whether to proceed, escalate, or block
 - Evidence must be sufficient for the risk level at each gate

 **Escalation Conditions:**
 - Issue exceeds this role's authority scope
 - Conflicting evidence that cannot be resolved within scope
 - Risk level exceeds what this role can authorize

 ### Workflow 4: Review Conflict Resolution

 **Trigger:** Two reviewers disagree on approach

 **Steps:**
    1. identify disagreement scope
2. evidence gathering
3. standards check
4. escalate if architectural

 **Decision Points:**
 - After each step, evaluate whether to proceed, escalate, or block
 - Evidence must be sufficient for the risk level at each gate

 **Escalation Conditions:**
 - Issue exceeds this role's authority scope
 - Conflicting evidence that cannot be resolved within scope
 - Risk level exceeds what this role can authorize

 ### Workflow 5: Large Diff Triage

 **Trigger:** PR exceeds 500 lines changed

 **Steps:**
    1. structural overview
2. risk-prioritized review order
3. identify split candidates
4. focused deep review

 **Decision Points:**
 - After each step, evaluate whether to proceed, escalate, or block
 - Evidence must be sufficient for the risk level at each gate

 **Escalation Conditions:**
 - Issue exceeds this role's authority scope
 - Conflicting evidence that cannot be resolved within scope
 - Risk level exceeds what this role can authorize


### Workflow: Ambiguous Request Handling

**Trigger:** Request is underspecified, has multiple valid interpretations, or lacks context

**Steps:**
1. Identify what is ambiguous and why
2. List the possible interpretations
3. Check KNOWLEDGE_SOURCES.md and Context7 for clarification
4. If still ambiguous, formulate specific clarifying questions
5. Do not guess — request clarification with structured options

**Decision Points:**
- Can ambiguity be resolved from existing sources? → resolve and proceed
- Must human clarify? → ask with specific options, not open-ended

**Escalation Conditions:**
- Ambiguity involves architectural decisions → escalate to software-architect
- Ambiguity involves governance scope → escalate to Sparky

### Workflow: Handoff Failure Recovery

**Trigger:** A handoff to or from another specialist is incomplete, missing context, or produces unexpected results

**Steps:**
1. Identify what is missing from the handoff
2. Check HANDOFF_TEMPLATES/ for the expected format
3. Document what was received vs what was expected
4. Request the specific missing artifacts from the handoff source
5. Do not proceed with incomplete handoff data

**Decision Points:**
- Can missing data be inferred safely? → infer with documented assumption
- Must source re-send? → request with specific list of missing items

**Escalation Conditions:**
- Repeated handoff failures from same source → escalate to Sparky
- Handoff failure blocks a critical path → escalate with timeline impact

---
*Each workflow should be tested against TEST_CASES.md scenarios during field validation.*
