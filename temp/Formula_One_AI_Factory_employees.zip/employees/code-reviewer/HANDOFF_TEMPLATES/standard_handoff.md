# Standard Handoff Template — Code Reviewer

## Handoff From: Code Reviewer
## Handoff To: [Specialist Name]
## Date: [Date]

## Context
[What is this about and why is it being handed off]

## Evidence Gathered
[What evidence has been collected so far]

## Known Blockers
[Any identified blockers or risks]

## Required Return Format
[What Code Reviewer needs back to continue]

## Urgency
[Time sensitivity and impact of delay]
