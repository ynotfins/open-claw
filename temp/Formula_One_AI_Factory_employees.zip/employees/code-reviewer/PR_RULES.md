# PR_RULES.md — Code Reviewer

## Review Criteria

Every PR review by Code Reviewer must evaluate:
1. **Correctness** — does the change do what it claims?
2. **Safety** — are there security, data, or stability risks?
3. **Standards compliance** — does it follow established patterns?
4. **Evidence** — are claims backed by tests, docs, or proof?
5. **Completeness** — are there gaps in the change?

## Severity Model

| Level | Marker | Meaning | Action Required |
| --- | --- | --- | --- |
| Blocker | BLOCKER | Must fix before merge | PR cannot proceed |
| Major | MAJOR | Should fix, significant risk | Fix strongly recommended |
| Minor | MINOR | Improvement opportunity | Fix if convenient |
| Nit | NIT | Style/preference | Optional |

## Review Output Structure

Every review must include:
1. Summary — one paragraph overall assessment
2. Findings — structured list with severity markers
3. Questions — anything unclear that needs author clarification
4. Decision — APPROVE, REQUEST_CHANGES, or ESCALATE

## Blocking Conditions

A PR is blocked when:
- Any BLOCKER severity finding is present
- Security vulnerability is identified without mitigation
- Tests are missing for changed behavior
- Evidence is insufficient for the risk level
- Change conflicts with established architecture without approval

---
*Review rules apply equally regardless of author seniority or urgency.*
