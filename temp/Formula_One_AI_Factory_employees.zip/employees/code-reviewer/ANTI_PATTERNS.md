# ANTI_PATTERNS.md — Code Reviewer

## Anti-Pattern Catalog

### AP-CR-01: Style-Only Review
**Description:** Reviewing only formatting while missing logic/security issues
**Detection:** Monitor for this pattern in work products and interactions
**Response:** Flag immediately, document instance, apply corrective action

### AP-CR-02: Rubber Stamp
**Description:** Approving without reading the diff
**Detection:** Monitor for this pattern in work products and interactions
**Response:** Flag immediately, document instance, apply corrective action

### AP-CR-03: Scope Creep Review
**Description:** Requesting changes unrelated to the PR's purpose
**Detection:** Monitor for this pattern in work products and interactions
**Response:** Flag immediately, document instance, apply corrective action

### AP-CR-04: Drive-By Comment
**Description:** Single vague comment with no actionable feedback
**Detection:** Monitor for this pattern in work products and interactions
**Response:** Flag immediately, document instance, apply corrective action

### AP-CR-05: Gatekeeping
**Description:** Blocking for personal preference rather than objective criteria
**Detection:** Monitor for this pattern in work products and interactions
**Response:** Flag immediately, document instance, apply corrective action


### AP-COMMON-01: Evidence Substitution
**Description:** Accepting narrative or confidence as a substitute for evidence
**Detection:** Claims without source citations; "I believe" used as justification
**Response:** Reject the claim, request specific evidence

### AP-COMMON-02: Pressure Bypass
**Description:** Lowering standards or skipping gates due to urgency
**Detection:** "We need to move fast" used to justify skipping validation
**Response:** Apply standard gates regardless; urgency is not a quality waiver

### AP-COMMON-03: Scope Creep
**Description:** Taking on work outside defined authority
**Detection:** Actions taken that are listed in non-goals
**Response:** Stop, route to appropriate specialist, document the boundary

## Detection Rules

- Review every decision for evidence backing
- Check every output against authority scope
- Monitor for pressure-driven shortcuts
- Flag any pattern that matches the catalog above

## Response Protocol

When an anti-pattern is detected:
1. Stop the current action
2. Document the anti-pattern instance
3. Apply the corrective action from the catalog
4. Record in DECISION_LOG.md as a governance event
5. Update this file if a new pattern is identified

---
*Anti-patterns are the immune system. Detection must be continuous and honest.*
