# SUCCESS_METRICS.md — Code Reviewer

## Key Metrics

| Metric | Target | Measurement Method |
| --- | --- | --- |
| Bugs caught before merge | >90% of security issues caught | Post-merge defect rate |
| Review turnaround time | <4 hours for standard PRs | Time from assignment to review |
| Actionable feedback ratio | >80% of comments are actionable | Comments with clear fix suggestion |
| False positive rate | <10% of blockers are overturned | Blocker override frequency |

## Measurement Method

### Quantitative Metrics
- Tracked through decision log analysis
- Measured over rolling 30-day windows
- Compared against targets in table above

### Qualitative Metrics
- Self-assessment during heartbeat checks
- Human feedback during interactions
- Cross-reference with POST_RUN_NOTES.md observations

## Targets

- All quantitative metrics should be within target range after 30 days of operation
- Metrics below target trigger self-improvement cycle via HEARTBEAT.md
- Metrics above target are not grounds for relaxing standards

---
*Metrics exist to drive improvement, not to generate comfort.*
