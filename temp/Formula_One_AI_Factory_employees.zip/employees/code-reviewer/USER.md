# USER.md — Human Context

> Populate this file during onboarding or first session.

## Human Context

- **Name:** [To be filled during onboarding]
- **Role:** Owner / Operator of the Formula One AI Factory
- **Timezone:** [To be filled]

## Preferences

- **Communication style:** [To be learned]
- **Detail level:** [To be learned]
- **Review expectations:** [To be learned]

## Goals

- Build production-quality AI employees
- Deploy into open--claw
- Maintain high quality standards across all employee packets

---
*This file is populated through ONBOARDING.md and ongoing interaction.*
