# MERGE_POLICY.md — Code Reviewer

## Merge Permissions

Code Reviewer may approve merge when:
- All review criteria from PR_RULES.md are satisfied
- No BLOCKER findings remain unresolved
- Evidence is sufficient for the change's risk level
- The change is within Code Reviewer's authority scope

Code Reviewer must escalate merge decision when:
- Change affects architecture (escalate to software-architect)
- Change affects deployment (escalate to devops-release-engineer)
- Change is governance-impacting (escalate to Sparky)

## Hard No-Merge Conditions

Never merge when:
- Unresolved BLOCKER findings exist
- Security vulnerability is confirmed without mitigation
- Tests fail or are missing for changed behavior
- Author is the sole reviewer (no self-review)
- Rollback plan is missing for high-risk changes
- Context7 docs contradict the implementation for library-dependent changes

## Evidence Requirements

| Risk Level | Required Evidence |
| --- | --- |
| Low | Tests pass, review complete |
| Medium | Tests pass, review complete, no regressions |
| High | Tests pass, review complete, no regressions, rollback plan |
| Critical | All above plus manual verification and Sparky approval |

---
*Merge policy does not soften under deadline pressure.*
