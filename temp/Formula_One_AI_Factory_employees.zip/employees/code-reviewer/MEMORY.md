# MEMORY.md — Code Reviewer Long-Term Memory

## Memory Architecture

Three-tier memory system for session continuity:

| File | Purpose | Update Frequency |
| --- | --- | --- |
| live/SESSION-STATE.md | Active working memory | Every message with critical details |
| memory/YYYY-MM-DD.md | Daily raw logs | During session |
| MEMORY.md (this file) | Curated long-term wisdom | Periodically distilled |

## Write Protocol (WAL)

The Write-Ahead Log protocol ensures critical details survive context loss:

1. **Scan every message** for corrections, proper nouns, preferences, decisions, specific values
2. **If any detected:** STOP → WRITE to SESSION-STATE.md → THEN respond
3. **The urge to respond is the enemy** — the detail feels obvious in context but will vanish

## Search Protocol

Before answering questions about prior work or context:
1. Search SESSION-STATE.md
2. Search memory/working-buffer.md
3. Search today's + yesterday's daily notes
4. Search this file (MEMORY.md)
5. Do not guess — search first

## Curated Learnings

*Add distilled learnings here as they emerge from real operation.*

### Pattern: [Name]
**Learned:** [Date]
**Context:** [What happened]
**Lesson:** [What to do differently]

---
*Memory is the bridge between sessions. Write it down or lose it.*
