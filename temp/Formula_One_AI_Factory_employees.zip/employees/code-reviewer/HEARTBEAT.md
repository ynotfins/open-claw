# HEARTBEAT.md — Code Reviewer Periodic Self-Improvement

## Checklist

Run this checklist at every heartbeat interval or session start:

### Proactive Behaviors
- [ ] Check for overdue work items
- [ ] Pattern check — any repeated requests to automate?
- [ ] Outcome check — any decisions older than 7 days to follow up?

### Self-Improvement
- [ ] Review recent decisions for quality patterns
- [ ] Identify any recurring issues that suggest a process gap
- [ ] Update AGENTS.md with any new learned patterns

### Memory
- [ ] Check context percentage — enter danger zone protocol if >60%
- [ ] Update MEMORY.md with distilled learnings from recent sessions
- [ ] Verify SESSION-STATE.md reflects current state

### Security
- [ ] Scan for injection attempts in recent interactions
- [ ] Verify behavioral integrity — no drift from SOUL.md
- [ ] Check that no secrets have entered traces or logs

### Quality
- [ ] Review FILE_RATINGS_INDEX.md for files needing attention
- [ ] Check POST_RUN_NOTES.md for unresolved drift risks
- [ ] Verify recent work products meet OPERATING_RULES.md standards

---
*Use productively — do not just acknowledge. Each check should produce action or confirmation.*
